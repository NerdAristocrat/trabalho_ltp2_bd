import gui
import bd

if __name__ == "__main__":
    try:
        gui.iniciar_interface()
    finally:
        bd.fechar_conexao()