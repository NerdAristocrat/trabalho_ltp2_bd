import tkinter as tk
from tkinter import messagebox, font
import bd

def iniciar_interface():
    root = tk.Tk()
    root.title("Cadastro de Alunos")
    root.geometry("1000x700")

    titulo_font = font.Font(root=root, family="Helvetica", size=14, weight="bold")

    def criar_titulo(frame, texto):
        label = tk.Label(frame, text=texto, font=titulo_font)
        label.pack(pady=(0,10))
        return label

    def criar_listbox_com_scroll(frame, width=40, height=12):
        frame_listbox = tk.Frame(frame)
        frame_listbox.pack(fill="both", expand=True)
        scrollbar = tk.Scrollbar(frame_listbox)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        listbox = tk.Listbox(frame_listbox, width=width, height=height, yscrollcommand=scrollbar.set)
        listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=listbox.yview)
        return listbox

    def add_placeholder(entry, texto):
        def on_focus_in(event):
            if entry.get() == texto:
                entry.delete(0, tk.END)
                entry.config(fg='black')
        def on_focus_out(event):
            if entry.get() == '':
                entry.insert(0, texto)
                entry.config(fg='gray')
        entry.insert(0, texto)
        entry.config(fg='gray')
        entry.bind("<FocusIn>", on_focus_in)
        entry.bind("<FocusOut>", on_focus_out)


    frame_linha1 = tk.Frame(root)
    frame_linha1.pack(fill="x", pady=10, padx=10)

    frame_linha2 = tk.Frame(root)
    frame_linha2.pack(fill="both", expand=True, pady=10, padx=10)

    frame_cadastro = tk.LabelFrame(frame_linha1, text="Cadastro de Aluno", padx=15, pady=15)
    frame_cadastro.pack(side=tk.LEFT, fill="both", expand=True, padx=10)

    frame_atualizar = tk.LabelFrame(frame_linha1, text="Atualizar Semestre", padx=15, pady=15)
    frame_atualizar.pack(side=tk.LEFT, fill="both", expand=True, padx=10)

    frame_exclusao = tk.LabelFrame(frame_linha1, text="Excluir Aluno", padx=15, pady=15)
    frame_exclusao.pack(side=tk.LEFT, fill="both", expand=True, padx=10)

    frame_email = tk.LabelFrame(frame_linha2, text="Adicionar Email", padx=15, pady=15)
    frame_email.pack(side=tk.LEFT, fill="both", expand=True, padx=10)

    frame_excluir_email = tk.LabelFrame(frame_linha2, text="Excluir Email", padx=15, pady=15)
    frame_excluir_email.pack(side=tk.LEFT, fill="both", expand=True, padx=10)

    frame_listas = tk.LabelFrame(frame_linha2, text="Listagens", padx=15, pady=15)
    frame_listas.pack(side=tk.LEFT, fill="both", expand=True, padx=10)

    tk.Label(frame_cadastro, text="Nome:").pack(anchor="w")
    entry_nome = tk.Entry(frame_cadastro, width=30)
    entry_nome.pack(pady=(0,5))
    add_placeholder(entry_nome, "Digite o nome do aluno")

    tk.Label(frame_cadastro, text="Semestre:").pack(anchor="w")
    entry_semestre = tk.Entry(frame_cadastro, width=30)
    entry_semestre.pack(pady=(0,10))
    add_placeholder(entry_semestre, "Digite o semestre (ex: 1)")

    def inserir():
        nome = entry_nome.get()
        semestre = entry_semestre.get()

        if nome == "" or nome == "Digite o nome do aluno" or semestre == "" or semestre == "Digite o semestre (ex: 1)":
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return
        
        try:
            semestre_int = int(semestre)
            bd.inserir_aluno(nome, semestre_int)
            bd.conexao.commit()
            messagebox.showinfo("Sucesso", f"Aluno {nome} cadastrado!")
            entry_nome.delete(0, tk.END)
            entry_semestre.delete(0, tk.END)
            add_placeholder(entry_nome, "Digite o nome do aluno")
            add_placeholder(entry_semestre, "Digite o semestre (ex: 1)")
        except ValueError:
            messagebox.showerror("Erro", "Semestre inválido")
        listar()
        listar_email_gui()

    tk.Button(frame_cadastro, text="Cadastrar", command=inserir).pack(pady=5, fill="x")

    tk.Label(frame_atualizar, text="Matrícula:").pack(anchor="w")
    entry_id_mudar = tk.Entry(frame_atualizar, width=30)
    entry_id_mudar.pack(pady=(0,5))
    tk.Label(frame_atualizar, text="Novo Semestre:").pack(anchor="w")
    entry_semestre_mudar = tk.Entry(frame_atualizar, width=30)
    entry_semestre_mudar.pack(pady=(0,10))

    def atualizar():
        semestre = entry_semestre_mudar.get()
        id_aluno = entry_id_mudar.get()
        if semestre == "" or id_aluno == "":
            messagebox.showwarning("Atenção", "Preencha todos os campos para atualizar!")
            return
        try:
            semestre_int = int(semestre)
            bd.mudar_semestre(semestre_int, id_aluno)
            bd.conexao.commit()
            messagebox.showinfo("Sucesso", f"Aluno {id_aluno} mudou de semestre!")
            entry_semestre_mudar.delete(0, tk.END)
            entry_id_mudar.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("Erro", "Semestre inválido")
        listar()

    tk.Button(frame_atualizar, text="Atualizar Semestre", command=atualizar).pack(pady=5, fill="x")

    tk.Label(frame_exclusao, text="Matrícula:").pack(anchor="w")
    entry_id = tk.Entry(frame_exclusao, width=30)
    entry_id.pack(pady=(0,10))

    def excluir():
        id_aluno = entry_id.get()
        if id_aluno == "":
            messagebox.showwarning("Atenção", "Informe a Matrícula para excluir!")
            return
        linhas_excluidas = bd.excluir_aluno(id_aluno)
        bd.conexao.commit()
        if linhas_excluidas == 0:
            messagebox.showinfo("Info", "Nenhum Aluno com essa Matrícula.")
        else:
            messagebox.showinfo("Sucesso", f"Aluno com Matrícula {id_aluno} excluído")
        entry_id.delete(0, tk.END)
        listar()
        listar_email_gui()

    tk.Button(frame_exclusao, text="Excluir Aluno", command=excluir).pack(pady=5, fill="x")

    tk.Label(frame_email, text="Email:").pack(anchor="w")
    entry_endereco = tk.Entry(frame_email, width=40)
    entry_endereco.pack(pady=(0,5))
    add_placeholder(entry_endereco, "exemplo@dominio.com")

    tk.Label(frame_email, text="Matrícula do Aluno:").pack(anchor="w")
    entry_id_aluno = tk.Entry(frame_email, width=30)
    entry_id_aluno.pack(pady=(0,10))

    def inserir_email():
        endereco = entry_endereco.get()
        id_aluno = entry_id_aluno.get()

        if endereco == "" or endereco == "exemplo@dominio.com" or id_aluno == "":
            messagebox.showwarning("Atenção", "Preencha todos os campos!")
            return
        
        try:
            id_int = int(id_aluno)
            bd.adicionar_email(endereco, id_int)
            bd.conexao.commit()
            messagebox.showinfo("Sucesso", f"Email {endereco} do Aluno {id_aluno} cadastrado!")
            entry_endereco.delete(0, tk.END)
            entry_id_aluno.delete(0, tk.END)
            add_placeholder(entry_endereco, "exemplo@dominio.com")
        except ValueError:
            messagebox.showerror("Erro", "Matrícula inválida")
        listar_email_gui()

    tk.Button(frame_email, text="Adicionar Email", command=inserir_email).pack(pady=5, fill="x")

    tk.Label(frame_excluir_email, text="ID do Email:").pack(anchor="w")
    entry_id_email = tk.Entry(frame_excluir_email, width=30)
    entry_id_email.pack(pady=(0,10))

    def excluir_email_gui():
        id_email = entry_id_email.get()
        if id_email == "":
            messagebox.showwarning("Atenção", "Informe o ID do Email para excluir!")
            return
        try:
            id_int = int(id_email)
            linhas_excluidas = bd.excluir_email(id_int)
            bd.conexao.commit()
            if linhas_excluidas == 0:
                messagebox.showinfo("Info", "Nenhum Email com esse ID.")
            else:
                messagebox.showinfo("Sucesso", f"Email com ID {id_email} excluído")
            entry_id_email.delete(0, tk.END)
            listar_email_gui()
        except ValueError:
            messagebox.showerror("Erro", "ID inválido")

    tk.Button(frame_excluir_email, text="Excluir Email", command=excluir_email_gui).pack(pady=5, fill="x")

    tk.Label(frame_listas, text="Alunos Cadastrados").pack(anchor="w")
    listbox = criar_listbox_com_scroll(frame_listas, width=50, height=12)

    tk.Label(frame_listas, text="Emails Cadastrados").pack(anchor="w", pady=(10,0))
    listbox2 = criar_listbox_com_scroll(frame_listas, width=50, height=12)

    def listar():
        listbox.delete(0, tk.END)
        alunos = bd.listar_alunos()
        for a in alunos:
            listbox.insert(tk.END, f"Matrícula: {a[0]} | {a[1]} | Semestre: {a[2]}")

    def listar_email_gui():
        listbox2.delete(0, tk.END)
        emails = bd.listar_emails()
        for e in emails:
            listbox2.insert(tk.END, f"ID Email: {e[0]} | Email: {e[1]} | Matrícula do aluno: {e[2]}")

    listar()
    listar_email_gui()

    root.mainloop()
