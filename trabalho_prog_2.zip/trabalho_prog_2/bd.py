import sqlite3

# Conexão e ativação de chave estrangeira
conexao = sqlite3.connect("alunos.bd")
conexao.execute("PRAGMA foreign_keys = ON")
cursor = conexao.cursor()

# Criação das tabelas
cursor.execute("""
CREATE TABLE IF NOT EXISTS alunos(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    semestre INTEGER NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS emails(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    endereco TEXT NOT NULL,
    id_aluno INTEGER,
    FOREIGN KEY (id_aluno) REFERENCES alunos(id) ON DELETE CASCADE
)
""")
conexao.commit()

# Inserir aluno com validação
def inserir_aluno(n, s):
    try:
        if not n.strip() or not isinstance(s, int) or s < 1:
            return "Erro: Nome não pode ser vazio e semestre deve ser um número inteiro positivo."
        cursor.execute("INSERT INTO alunos (nome, semestre) VALUES (?, ?)", (n.strip(), s))
        conexao.commit()
        return "Aluno inserido com sucesso."
    except sqlite3.Error as e:
        return f"Erro ao inserir aluno: {e}"

# Listar alunos
def listar_alunos():
    try:
        cursor.execute("SELECT * FROM alunos")
        return cursor.fetchall()
    except sqlite3.Error as e:
        return f"Erro ao listar alunos: {e}"

# Excluir aluno
def excluir_aluno(id_aluno):
    try:
        cursor.execute("DELETE FROM alunos WHERE id = ?", (id_aluno,))
        conexao.commit()
        if cursor.rowcount == 0:
            return "Erro: Nenhum aluno encontrado com o ID fornecido."
        return "Aluno excluído com sucesso."
    except sqlite3.Error as e:
        return f"Erro ao excluir aluno: {e}"

# Atualizar semestre
def mudar_semestre(s, id_aluno):
    try:
        if not isinstance(s, int) or s < 1:
            return "Erro: O semestre deve ser um número inteiro positivo."
        cursor.execute("UPDATE alunos SET semestre = ? WHERE id = ?", (s, id_aluno))
        conexao.commit()
        if cursor.rowcount == 0:
            return "Erro: Nenhum aluno encontrado com o ID fornecido."
        return "Semestre atualizado com sucesso."
    except sqlite3.Error as e:
        return f"Erro ao atualizar semestre: {e}"

# Adicionar email com validação
def adicionar_email(e, id_aluno):
    try:
        if "@" not in e or "." not in e:
            return "Erro: Endereço de email inválido."
        cursor.execute("INSERT INTO emails (endereco, id_aluno) VALUES (?, ?)", (e.strip(), id_aluno))
        conexao.commit()
        return "Email adicionado com sucesso."
    except sqlite3.IntegrityError:
        return "Erro: Aluno não encontrado para associar o email."
    except sqlite3.Error as e:
        return f"Erro ao adicionar email: {e}"

# Listar emails
def listar_emails():
    try:
        cursor.execute("SELECT * FROM emails")
        return cursor.fetchall()
    except sqlite3.Error as e:
        return f"Erro ao listar emails: {e}"

# Excluir email
def excluir_email(id_email):
    try:
        cursor.execute("DELETE FROM emails WHERE id = ?", (id_email,))
        conexao.commit()
        if cursor.rowcount == 0:
            return "Erro: Nenhum email encontrado com o ID fornecido."
        return "Email excluído com sucesso."
    except sqlite3.Error as e:
        return f"Erro ao excluir email: {e}"

# Fechar conexão
def fechar_conexao():
    try:
        conexao.close()
        return "Conexão encerrada com sucesso."
    except sqlite3.Error as e:
        return f"Erro ao fechar conexão: {e}"

